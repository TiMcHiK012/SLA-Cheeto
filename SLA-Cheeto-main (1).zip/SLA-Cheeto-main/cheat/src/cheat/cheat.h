#pragma once

void init_cheat();
void run_cheat();