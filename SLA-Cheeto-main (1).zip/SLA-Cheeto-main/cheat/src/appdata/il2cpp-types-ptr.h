// Generated C++ file by Il2CppInspector - http://www.djkaty.com - https://github.com/djkaty
// Target Unity version: 2021.2.0+

// ******************************************************************************
// * IL2CPP application-specific type definition addresses
// ******************************************************************************

//DO_TYPEDEF(0x0, Int32);